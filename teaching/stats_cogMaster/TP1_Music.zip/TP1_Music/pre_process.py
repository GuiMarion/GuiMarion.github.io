import numpy as np
import librosa
from glob import glob
import pickle
from tqdm import tqdm
np.random.seed(1) # For reproductability

N = 100 # Number of files to include in each dataset

houseum = []
files = glob("houseum/*.mp3")
np.random.shuffle(files)
for file in tqdm(files[:N]):
	print(file)
	data, fs = librosa.load(file)
	houseum.append((data, fs))

pickle.dump(houseum, open("houseum/pre_processed.data", "wb"))

hate = []
files = glob("hate/*.mp3")
np.random.shuffle(files)
for file in tqdm(files[:N]):
	print(file)
	data, fs = librosa.load(file)
	hate.append((data, fs))

pickle.dump(hate, open("hate/pre_processed.data", "wb"))