#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Oct 24 18:43:27 2020

@author: gui
"""

import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm
from tempo_extraction.tempo_extraction import tempo_extraction as tempo_extraction
import pickle 
import librosa
import seaborn as sns
from scipy import stats, fft
import pyloudnorm as pyln
from statsmodels.stats import multitest
from scipy.interpolate import interp1d
from scipy.signal import hilbert

print("Everything's working fine!")

#%% Import pre-processed data
#houseum = pickle.load(open("houseum/pre_processed.data", "rb"))
#hate = pickle.load(open("hate/pre_processed.data", "rb"))

