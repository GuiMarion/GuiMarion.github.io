#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Oct 25 10:36:43 2020

@author: gui
"""
def find_nearest(array,value):
    idx = np.searchsorted(array, value, side="left")
    if idx > 0 and (idx == len(array) or math.fabs(value - array[idx-1]) < math.fabs(value - array[idx])):
        return idx-1
    else:
        return idx

import numpy as np
from scipy.io.wavfile import write
import matplotlib.pyplot as plt
from playsound import playsound
import librosa
import math
import os

f0 = 220 # Fondamental frequency
B = 0.00 # Inharmonicity coefficient (B=0:no inharmonicity, piano A4: B=0.00124)
n = 30 # number of patials 

B_max = 0.01
N = 70

timbre = "rhodes.wav"
for timbre in ["rhodes.wav", "flute.wav", "fiddle.wav", "alto.wav", "piano.wav"]:
    if not os.path.exists("out/static/"+timbre):
        os.mkdir("out/static/"+timbre)
    files = []
    for B in np.linspace(0, B_max, N):
        print(B)
    
        fs = 44100
        length = 0.500 # in seconds
        
        X = 2*np.pi*np.arange(fs*length)/fs
        Y = np.sin(X*f0)*0
        
        # We import a rhodes sounds to extract the partials amplitudes
        y, fs_y = librosa.load(timbre)
        y_f= abs(np.fft.fft(y))
        xf = np.linspace(0.0, 1.0/(2.0*(1/fs_y)), len(y_f)//2)
        amplitudes = [0]
        for i in range(1, n):
            f = i*f0 # Partial frequency
            ind = find_nearest(xf, f)
            ep = find_nearest(xf, 10)
            a = np.max(y_f[ind-ep:ind+ep])# Partial amplitude
            amplitudes.append(a)
        
        
        L = []
        for i in range(1, n):
            f = i*np.sqrt(1+B*i**2)*f0/np.sqrt(1+B) # Partial frequency
            Y += amplitudes[i]*np.sin(X*f)/n
            L.append(f)
        
        Y = Y/np.max(abs(Y))*0.6
        
        
        # freq = abs(np.fft.fft(Y))
        # freq = freq/np.std(freq)
        # y_f = y_f/np.std(y_f)
        # plt.figure(2)
        # plt.subplot(2,1,1)
        # xf = np.linspace(0.0, 1.0/(2.0*(2/fs)), len(freq)//4)
        # plt.plot(xf, freq[:len(freq)//4])
        # plt.title("Ours")
        
        # plt.subplot(2,1,2)
        # xf = np.linspace(0.0, 1.0/(2.0*(1/fs_y)), len(y_f)//2)
        # plt.plot(xf, y_f[:len(y_f)//2])
        # plt.title("Rhodes")
        # plt.show()
        
        files.append(Y)
        Y = np.int16(Y * 32767) # Transform to integers for scipy
        # Write the .wav file
        write("out/static/"+timbre+"/synth_B_"+format(round(B, 3), '03f')+".wav", fs, Y)
        
    #%% We construct a morph
        
    file_morph = np.zeros(len(Y)*(N//2+1))
    envelope_in = 1/(len(Y)//2)*np.arange(len(Y))
    envelope_out = (-1/(len(Y)//2))*np.arange(len(Y))+2
    envelope = envelope_in
    envelope[len(Y)//2:]= envelope_out[len(Y)//2:]
    
    for i in range(len(files)):
        file_morph[i*len(Y)//2:i*len(Y)//2 + len(Y)] += envelope*files[i]
    
    plt.figure()
    plt.plot(file_morph)
    plt.show()
    write("out/static/"+timbre+"/morph.wav", fs, np.int16(file_morph * 32767))
    
        