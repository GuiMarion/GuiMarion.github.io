#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Oct 25 13:20:06 2020

@author: gui
"""
def find_nearest(array,value):
    idx = np.searchsorted(array, value, side="left")
    if idx > 0 and (idx == len(array) or math.fabs(value - array[idx-1]) < math.fabs(value - array[idx])):
        return idx-1
    else:
        return idx

import numpy as np
from scipy.io.wavfile import write
import matplotlib.pyplot as plt
from playsound import playsound
import librosa
import math
from tqdm import tqdm


for timbre in ["rhodes.wav", "flute.wav", "fiddle.wav", "alto.wav", "piano.wav"]:

    f0 = 220 # Fondamental frequency
    B = 0.003 # Inharmonicity coefficient (B=0:no inharmonicity, piano A4: B=0.00124)
    n = 30 # number of patials 
    
    fs = 44100
    length = 10 # in seconds
    
    X = 2*np.pi*np.arange(fs*length)/fs
    Y = np.sin(X*f0)*0
    
    directions = (np.random.rand(n)-0.5)*20
    directions[1] = 0 # We do not touch the fondamental
    
    # We import a rhodes sound to extract the partials amplitudes
    y, fs_y = librosa.load(timbre)
    y_f= abs(np.fft.fft(y))
    xf = np.linspace(0.0, 1.0/(2.0*(1/fs_y)), len(y_f)//2)
    amplitudes = [0]
    for i in range(1, n):
        f = i*f0 # Partial frequency
        ind = find_nearest(xf, f)
        ep = find_nearest(xf, 10)
        a = np.max(y_f[ind-ep:ind+ep])# Partial amplitude
        amplitudes.append(a)
    
    Bs = np.linspace(0, B, len(X))
    for x in tqdm(range(len(X))):
        B = Bs[x]
        for i in range(1, n):
            #f = i*f0 + directions[i]*np.sqrt(1+B*i**2) # Partial frequency random
            f = i*np.sqrt(1+B*i**2)*f0/np.sqrt(1+B) # Partial frequency piano
            
            Y[x] += amplitudes[i]*np.sin(X[x]*f)/n
    
    Y = Y/np.max(abs(Y))*0.6
    Y = np.int16(Y * 32767) # Transform to integers for scipy
    # Write the .wav file
    write("out/dynamic/"+timbre+"_B_"+format(round(B, 3), '02f')+".wav", fs, Y)
            