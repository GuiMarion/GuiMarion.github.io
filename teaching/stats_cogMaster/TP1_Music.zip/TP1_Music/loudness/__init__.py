import numpy as np
import matplotlib.pyplot as plt # plots
import copy # edit in place

__all__ = ['filters', 'loudness']