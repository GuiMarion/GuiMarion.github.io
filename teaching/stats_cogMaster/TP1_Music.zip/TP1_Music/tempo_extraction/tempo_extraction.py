import numpy as np
import librosa
from scipy import signal
from scipy import fft
import matplotlib.pyplot as plt
import time

def tempo_extraction(data, fs, stride=2205, window_size=2048, plot=False):
	# window_size = 2048  # 2048-sample fourier windows
	# stride = 2205        # 512 samples between windows
	wps = fs/float(stride) # number of windows by second
	Xs = np.empty([int(((data.shape[0]-window_size)/fs)*wps),window_size])

	for i in range(Xs.shape[0]):
	    Xs[i] = np.abs(fft(data[i*stride:i*stride+window_size]))

	Xs = Xs[:, :100]
	envelope = np.mean(Xs, 1)


	if plot and False:
		fig = plt.figure(1)
		plt.imshow(np.log(Xs.T[0:150]),aspect='auto')
		plt.gca().invert_yaxis()
		fig.axes[0].set_xlabel('windows (~86Hz)')
		fig.axes[0].set_ylabel('frequency')
		plt.show()

		fig = plt.figure(2)
		plt.plot(envelope)
		plt.show()


	corr = np.correlate(envelope, envelope, mode="same")

	if plot and False:
		fig = plt.figure(3)
		plt.plot(corr)
		plt.show()

	yf = fft(corr)
	yf[:10] = 0 # We filter the low frequencies to remove the autocor side effects
	xf = np.linspace(0.0, 1.0/(2.0/wps), len(corr)//2)*60
	if plot:
		fig = plt.figure(4)
		plt.plot(xf, 2.0/len(corr)*np.abs(yf[0:len(corr)//2]))
		plt.grid()
		plt.show()

	return xf[np.argmax(2.0/len(corr)*np.abs(yf[0:len(corr)//2]))]


# data1, fs1 = librosa.load("funk_112.wav")

# tempo1 = tempo_extraction(data1, fs1, plot=False)
# print(tempo1)

